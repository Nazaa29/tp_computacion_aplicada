#!/bin/bash

# Llamada a la función esLaborable() en el script esLaborable.sh con el primer argumento
bash /opt/tp/scripts/esLaborable.sh 2023-05-31
