#!/bin/bash

#Creo la funcion mostrar_ayuda() que mas adelante se llamara a la misma con -h

mostrar_ayuda() {
    echo "Uso: backup_full.sh -o <origen> -d <destino>"
    echo "Realiza un backup de <origen> a <destino>"
    echo "Opciones:"
    echo "  -o <origen>   Directorio de origen del backup"
    echo "  -d <destino>  Directorio de destino del backup"
    echo "  -h            Muestra esta ayuda"
}

#Funcion generar_log genera la fecha y la almacena en timestamp y luego concatena el primer parametro pasado en una cadena de caracteres junto a timestamp. Lo redirige a backup.log, lo que significa que lo agrega al final y no sobreescribe.

generar_log() {
    timestamp=$(date +"%H:%M:%S")
    echo "$timestamp - $1" >> backup.log
}

# Rutas de los sistemas de archivos origen y destino
ruta_logs="/var/log"
ruta_etc="/etc"
ruta_u01="/u01"
ruta_u02="/u02"
ruta_destino="/u03"

#Establezco las opciones o:d:h con sus respectivas funcionalidades
#$OPTARG es una variable especial que almacena el valor del argumento pasado junto con la opcion

generar_log "Iniciando ejecucion del script"

while getopts "o:d:h" option; do
    case $option in
        o) origen=$OPTARG ;;
        d) destino=$OPTARG ;;
        h) mostrar_ayuda; exit ;;
        *) generar_log "Error: ("$option") parámetro desconocido." mostrar_ayuda; exit 1 ;;
    esac
done

# -z verifica que la cadena no este vacia, si esta vacia muestra un error por pantalla y llama a la funcion.

if [[ -z $origen || -z $destino ]]; then
    echo "Error: Se deben especificar el origen (-o) y el destino (-d)"
    generar_log "Error: el origen o el destino estan vacios"
    mostrar_ayuda
    exit 1
fi

# -d prueba que el directorio exista. Si no existe el directorio muestra un error.

if [[ ! -d $destino ]]; then
    echo "Error: "$destino" no existe o no es un directorio válido."
    generar_log "Error: destino no encontrado"
    exit 1
elif [[ "$destino" != "$ruta_destino" ]]; then
    echo "Atencion: "$destino" erroneo. Debe ser "$ruta_destino""
    generar_log "El directorio origen es distinto de la ruta"
    exit 1
fi

if [[ ! -d $origen ]]; then
    echo "Error: "$origen" no existe o no es un directorio válido."
    generar_log "Error: origen no encontrado"
    exit 1
fi

# Obtener la fecha actual
fecha_actual=$(date +%Y%m%d)

# Obtener la hora actual
hora_actual=$(date +%H)

generar_log "Iniciando backups"

# Realizar backup de $origen a $destino todos los días a las 00:00

if [[ "$hora_actual" == "00"  &&  "$origen" == "$ruta_logs" ]]; then
    if [[ "$ruta_logs" == "$origen" ]]; then
        tar -czvf "$destino/logs_bck_$fecha_actual.tar.gz" "$origen"
        echo "Backup de $origen realizado correctamente en $destino."
        generar_log "Backup $origen creado correctamente en $destino"
    elif [[ "$ruta_etc" == "$origen" ]]; then
        tar -czvf "$destino/etc_bck_$fecha_actual.tar.gz" "$origen"
        echo "Backup de $origen realizado correctamente en $destino."
        generar_log "Backup $origen creado correctamente en $destino"
    else
        echo "No se genero el backup de "$origen" porque no coincide con "$ruta_logs" ni con "$ruta_etc""
        generar_log "No se genero el backup de "$origen" porque no coincide con "$ruta_logs" ni con "$ruta_etc""
    fi
else 
    echo "No se genero el backup de "$origen" porque no coincide no son las 00:HS"
    generar_log "No se genero el backup de "$origen" porque no coincide no son las 00:HS"
fi

# Realizar backup de $origen a $destino los domingos a las 23:00
# $(date +%u) Me devuelve un valor del 1 al 7 dependiendo del dia.
dia_semana=$(date +%u)
if [[ "$dia_semana" == "7" && "$hora_actual" == "23" ]]; then
    if [[ "$ruta_u01" == "$origen" ]]; then
        tar -czvf "$destino/u01_bck_$fecha_actual.tar.gz" "$origen"
        echo "Backup de $origen realizado correctamente en $destino."
        generar_log "Backup de $origen generado correctamente en $destino"
    elif [[ "$ruta_u02" == "$origen" ]]; then
        tar -czvf "$destino/u02_bck_$fecha_actual.tar.gz" "$origen"
        echo "Backup de $origen realizado correctamente en $destino."
        generar_log "Backup de $origen generado correctamente en $destino"
    else 
        echo "No se genero el backup de "$origen" porque no coincice con "$ruta_u01" ni con "$ruta_u02""
        generar_log "No se genero el backup de "$origen" porque no coincice con "$ruta_u01" ni con "$ruta_u02""
    fi
fi

# Mandamos el log via mail local a root
echo "Envio informe de logs via mail" | mail -s "Logs: "$backup_log"" root

# Elimino el archivo .log para que cuando se vuelva a ejecutar no exista un backup.log
rm backup.log
