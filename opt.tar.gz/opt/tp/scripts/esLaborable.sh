#!/bin/bash

# Función para determinar si una fecha es laborable o no
esLaborable() {
  local fecha="$1" # El primer parámetro recibido se asigna a la variable fecha
  local diaSemana=$(date -d "$fecha" +%u)  # Obtener el día de la semana (1-7) desde la fecha introducida
  local esFeriado=false

  # Verificar si es fin de semana (sábado: 6, domingo: 7)
  if [[ $diaSemana -eq 6 || $diaSemana -eq 7 ]]; then
    echo "El $fecha es fin de semana."
    return 1  # No laborable
  fi

  # Leer los feriados desde el archivo y almacenarlos en una variable
  local feriados=$(cat /opt/tp/scripts/feriados.txt)

  # Verificar si es un feriado en Argentina
  local fechaFeriado=$(date -d "$fecha" +%d%m%Y)
  if grep -q "$fechaFeriado" <<< "$feriados"; then
    echo "El $fecha es feriado nacional."
    esFeriado=true
  fi

  if [ "$esFeriado" = true ]; then
    return 1  # No laborable
  else
    echo "Es día laboral"
    return 0  # Laborable
  fi
}

# Verificar si se proporciona un solo argumento
if [ $# -ne 1 ]; then
  echo "Uso: $0 <fecha>"
  exit 1
fi

# Llamada a la función con el primer argumento
esLaborable "$1"
