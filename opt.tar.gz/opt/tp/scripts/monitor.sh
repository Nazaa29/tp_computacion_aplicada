#!/bin/bash

# Verificar si se proporciona un argumento
if [ $# -eq 0 ]; then
  echo "Por favor, proporciona el nombre del proceso como argumento."
  exit 1
fi

# Nombre del proceso a monitorear
proceso=$1

# Comprobar si el proceso está en ejecución
# pgrep busca y muestra los identificadores de procesos que coincidan
# -x pide que busque exactamente el nombre del proceso

if pgrep -x "$proceso" >/dev/null; then
  echo "El proceso $proceso está en ejecución."
else
  echo "El proceso $proceso no se encuentra en ejecución. Enviando correo electrónico al usuario root..."

  # Enviar correo electrónico al usuario root utilizando mutt
  echo "El proceso $proceso no se encuentra en ejecución. Por favor, verifique el estado del servicio." | mail -s "Alerta de monitoreo - $proceso" root
fi
